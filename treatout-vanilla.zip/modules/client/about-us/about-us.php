<!-- Main -->
<div id="heading" >
	<h1> About Us</h1>
</div>

<section id="main" >
        <div class="inner">
            <div class="content">

            <header class="special">
                <i class="icon fa-map" style="font-size:100px;">&nbsp;</i>
                <h1>We help you find your way</h1>
                <h3>
                    Treatout is a food locator for Bacolod city and tourist spot locator for Nengros occidental. treatout helps you find public transportation going to your desired destination.
                </h3>
            </header>
            <br/>
            <br/>
            <br/>
            <header class="special">

            </header>   
            </div>
        </div>
</section>


<section id="main" >
        <div class="inner">
            <div class="content">
                <h2>Members</h2>
                <div class="highlights">
                    <section>
                        <div class="content">
                            <header>
                                <a class="icon fa-male"><span class="label">Icon</span></a>
                                <h3>Name</h3>
                            </header>
                            <p>Position</p>
                        </div>
                    </section>
                    <section>
                        <div class="content">
                            <header>
                                <a class="icon fa-male"><span class="label">Icon</span></a>
                                <h3>Name</h3>
                            </header>
                            <p>Position</p>
                        </div>
                    </section>
                    <section>
                        <div class="content">
                            <header>
                                <a class="icon fa-male"><span class="label">Icon</span></a>
                                <h3>Name</h3>
                            </header>
                            <p>Position</p>
                        </div>
                    </section>
  
                </div>
            </div>
        </div>
</section>

