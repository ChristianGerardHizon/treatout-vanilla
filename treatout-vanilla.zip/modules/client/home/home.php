<section id="cta" class="wrapper">
    <div class="inner">
        <h1>TREATOUT</h1>
        <p class="paragraph">WE'LL HELP YOU FIND YOUR DESTINATION</p>
    </div>
</section>
<section class="wrapper">
				<div class="inner">
					<header class="special">
						<h1>Search Your Most Desired Places Here</h1>
						<h3>
							Don't know where to Eat and Visit here in Negros?<br/>
							We got you fam! 
						</h3>
					</header>
					<div class="highlights">

						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=search" class="icon fa-map"><span class="label">Icon</span></a>
									<h3>Search</h3>
								</header>
								<p>Can't Decide or She does not know where to go or eat? Oh boy let help you with that</p>
							</div>
						</section>
						
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=places&service=tourist+spot" class="icon fa-paper-plane-o"><span class="label">Icon</span></a>
									<h3>Tourist Spots</h3>
								</header>
								<p>Its a bird! Its a Plane! No it's a Famous Tourist Attraction. Let me show you how to get there</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=places&service=restaurant" class="icon fa-cutlery"><span class="label">Icon</span></a>
									<h3>Restaurants</h3>
								</header>
								<p>Hungry? or Craving Somethin? Treatout will point the way </p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=contact-us" class="icon fa-vcard-o"><span class="label">Icon</span></a>
									<h3>Contact Us</h3>
								</header>
								<p>Wanna add or change Something? We will make sure your business or favorite spot is here.</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=about-us" class="icon fa-users"><span class="label">Icon</span></a>
									<h3>About Us</h3>
								</header>
								<p>Wanna know about us? Really? We will show you a brief but not long history of our site</p>
							</div>
						</section>
	
					</div>
				</div>
			</section>

		<!-- Footer -->
			<footer id="footer">
				<div class="inner">

					<div class="copyright">
						&copy; Treatout 2018
					</div>
				</div>
			</footer>
