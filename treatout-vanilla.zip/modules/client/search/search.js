// const search = document.getElementById('search')
// const query = document.getElementById('queryStr')

// const minBudget = document.getElementById('min_budget')
// const maxBudget = document.getElementById('max_budget') 

// search.addEventListener('click', function( data ) {
//     console.log(query.value)
//     if( !minBudget.value && !maxBudget.value ){

//         if( minBudget.value > maxBudget.value){
//             alert('Minimum Value is greater than Maximum');
//             return
//         } 
//         alert('You have not set your budget')
//         return
//     }
    
//     search.href = `http://localhost/treatout/index.php?mod=places&service=search&min=${minBudget.value}&max=${maxBudget.value}&query=${query.value}`
// })