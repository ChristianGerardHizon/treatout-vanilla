

<section class="wrapper">
				<div class="inner">
					<header class="special">
						<h2>admin dashboard</h2>
					</header>
					<div class="highlights">
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=places&service=tourist+spot" class="icon fa-paper-plane-o"><span class="label">Icon</span></a>
									<h3>Tourist Spots</h3>
								</header>
								<p>Its a bird! Its a Plane! No it's a Famous Tourist Attraction. Let me show you how to get there</p>
							</div>
						</section>
						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=places&service=restaurant" class="icon fa-cutlery"><span class="label">Icon</span></a>
									<h3>Restaurants</h3>
								</header>
								<p>Hungry? or Craving Somethin? Treatout will point the way </p>
							</div>
						</section>


						<section>
							<div class="content">
								<header>
									<a href="index.php?mod=account" class="icon fa-floppy-o"><span class="label">Icon</span></a>
									<h3>User Accounts</h3>
								</header>
								<p>Can't Remember that last place you visited? or just want to save a restaurant or place for that special date? We got you covered</p>
							</div>
						</section>
					</div>
				</div>
			</section>

		