const SERVER_URL = "http://localhost:3000"
const CORS_FIX = "https://cors-anywhere.herokuapp.com/"
const GMAPS_API_KEY = `AIzaSyDWJ95wDORvWwB6B8kNzSNDfVSOeQc8W7k`;